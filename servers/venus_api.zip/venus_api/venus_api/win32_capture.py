"""Win32 window capture for screen streaming.

Captures screenshots of a target application window using Win32 API.
Ported from the standalone screen-streaming project's win32_stream.py.

Requires: pywin32, Pillow, opencv-python, numpy
These are Windows-only dependencies.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)


def _init_dpi_awareness() -> None:
    """Set per-monitor DPI awareness for accurate pixel dimensions."""
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def find_window_by_substring(substring: str) -> Optional[int]:
    """Find a window whose title contains the given substring."""
    import win32gui

    result = []
    def callback(hwnd, _):
        if win32gui.IsWindowVisible(hwnd) or win32gui.IsIconic(hwnd):
            title = win32gui.GetWindowText(hwnd)
            if substring.lower() in title.lower():
                result.append(hwnd)
        return True
    win32gui.EnumWindows(callback, None)
    return result[0] if result else None


def capture_window(hwnd: int) -> Optional[bytes]:
    """Capture the client area of a window. Returns JPEG bytes or None."""
    import ctypes
    import cv2
    import numpy as np
    import win32con
    import win32gui
    import win32ui
    from PIL import Image

    is_minimized = win32gui.IsIconic(hwnd)
    rect = win32gui.GetClientRect(hwnd)
    width, height = max(rect[2], 1), max(rect[3], 1)

    if width <= 1 or height <= 1:
        placement = win32gui.GetWindowPlacement(hwnd)
        rc = placement[4]
        width = max(rc[2] - rc[0], 1)
        height = max(rc[3] - rc[1], 1)

    if width <= 1 or height <= 1:
        return None

    hwndDC = win32gui.GetWindowDC(hwnd)
    mfcDC = win32ui.CreateDCFromHandle(hwndDC)
    saveDC = mfcDC.CreateCompatibleDC()

    try:
        saveBitMap = win32ui.CreateBitmap()
        saveBitMap.CreateCompatibleBitmap(mfcDC, width, height)
        saveDC.SelectObject(saveBitMap)

        captured = False

        if not is_minimized:
            captured = ctypes.windll.user32.PrintWindow(hwnd, saveDC.GetSafeHdc(), 3) == 1

        if not captured:
            PRF_CLIENT = 0x00000004
            PRF_CHILDREN = 0x00000010
            PRF_OWNED = 0x00000020
            win32gui.SendMessage(
                hwnd, win32con.WM_PRINT, saveDC.GetSafeHdc(),
                PRF_CLIENT | PRF_CHILDREN | PRF_OWNED
            )
            bmpstr = saveBitMap.GetBitmapBits(True)
            if any(b != 0 for b in bmpstr[:1000]):
                captured = True

        if not captured:
            saveDC.BitBlt((0, 0), (width, height), mfcDC, (0, 0), win32con.SRCCOPY)
            bmpstr = saveBitMap.GetBitmapBits(True)
            if any(b != 0 for b in bmpstr[:1000]):
                captured = True

        if captured:
            bmpinfo = saveBitMap.GetInfo()
            bmpstr = saveBitMap.GetBitmapBits(True)
            im = Image.frombuffer(
                'RGB',
                (bmpinfo['bmWidth'], bmpinfo['bmHeight']),
                bmpstr, 'raw', 'BGRX', 0, 1)
            frame = np.array(im)
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            if ret:
                return buffer.tobytes()

        return None
    finally:
        win32gui.DeleteObject(saveBitMap.GetHandle())
        saveDC.DeleteDC()
        mfcDC.DeleteDC()
        win32gui.ReleaseDC(hwnd, hwndDC)


class ScreenCapture:
    """Background screen capture thread for a target window."""

    def __init__(self) -> None:
        self._target_title: Optional[str] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._last_jpeg: Optional[bytes] = None
        self._frame_lock = threading.Lock()

    @property
    def is_capturing(self) -> bool:
        return self._running and self._thread is not None and self._thread.is_alive()

    @property
    def latest_frame(self) -> Optional[bytes]:
        with self._frame_lock:
            return self._last_jpeg

    def start(self, window_title: str) -> None:
        """Start capturing a window matching the title substring.

        Raises RuntimeError if the window is not found.
        """
        _init_dpi_awareness()

        hwnd = find_window_by_substring(window_title)
        if hwnd is None:
            raise RuntimeError(f"No window found matching '{window_title}'")

        self.stop()
        self._target_title = window_title
        self._running = True
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()
        logger.info("Screen capture started for window: %s", window_title)

    def stop(self) -> None:
        """Stop the capture thread."""
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        self._last_jpeg = None
        logger.info("Screen capture stopped")

    def _capture_loop(self) -> None:
        """Background loop that continuously captures the target window."""
        while self._running:
            try:
                hwnd = find_window_by_substring(self._target_title)
                if hwnd:
                    jpeg = capture_window(hwnd)
                    if jpeg is not None:
                        with self._frame_lock:
                            self._last_jpeg = jpeg
            except Exception as e:
                logger.debug("Capture error: %s", e)
            time.sleep(0.1)
